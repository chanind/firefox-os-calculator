(function() {
  this.Calculator = angular.module('Calculator', []);

  Calculator.controller('CalculatorCtrl', function($scope) {
    var errorTimeout, math;
    math = mathjs();
    errorTimeout = null;
    $scope.cursorPosition = 0;
    $scope.expression = '';
    $scope.insertChar = function(char) {
      return $scope.expression += char;
    };
    $scope.clear = function() {
      return $scope.expression = '';
    };
    return $scope.evaluate = function() {
      var exception;
      if (!$scope.expression) {
        return;
      }
      try {
        return $scope.expression = math["eval"]($scope.expression.replace('×', '*')).toString();
      } catch (_error) {
        exception = _error;
        $scope.error = true;
        clearTimeout(errorTimeout);
        return errorTimeout = setTimeout((function() {
          return $scope.$apply(function() {
            return $scope.error = false;
          });
        }), 1500);
      }
    };
  });

}).call(this);
